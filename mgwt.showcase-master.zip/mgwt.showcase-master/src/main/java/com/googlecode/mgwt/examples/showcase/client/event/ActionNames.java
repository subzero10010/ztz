package com.googlecode.mgwt.examples.showcase.client.event;

public interface ActionNames {
	public static final String BACK = "back";
	public static final String ANIMATION_END = "ae";
}
